# Faris Alghazi Pratama — Portfolio

Portfolio statis pribadi untuk memperkenalkan pengalaman PKL, proyek/lab, kompetensi teknis, pendidikan, dan kontak.

## Struktur folder

```text
portfolio-faris-github/
├── index.html
├── README.md
├── .gitignore
├── .nojekyll
├── assets/
│   ├── foto-faris.jpg
│   ├── favicon.svg
│   ├── pkl-1.jpg ... pkl-4.jpg
│   └── proyek-nmap.jpg ... proyek-wireshark.jpg
├── css/
│   └── style.css
└── js/
    └── main.js
```

## Menjalankan secara lokal

1. Ekstrak folder proyek.
2. Buka `index.html` di browser.
3. Koneksi internet diperlukan untuk memuat Tailwind CSS melalui CDN.

Untuk pengalaman lokal yang lebih konsisten, jalankan server statis dari folder ini:

```bash
python3 -m http.server 8000
```

Lalu buka `http://localhost:8000`.

## Mengganti gambar dokumentasi

Semua gambar berada di folder `assets/`.

- Foto profil: `assets/foto-faris.jpg` (sudah diisi dengan foto yang diberikan).
- Dokumentasi PKL: `assets/pkl-1.jpg` sampai `assets/pkl-4.jpg`.
- Dokumentasi proyek: `assets/proyek-nmap.jpg`, `proyek-windows.jpg`, `proyek-ngrok.jpg`, `proyek-mikrotik.jpg`, `proyek-debian.jpg`, dan `proyek-wireshark.jpg`.

File `pkl-*.jpg` dan `proyek-*.jpg` yang tersedia sekarang adalah **placeholder**, bukan bukti kegiatan asli. Ganti file placeholder dengan foto/screenshot milik sendiri menggunakan nama file yang sama. Dengan begitu, `index.html` dan `js/main.js` tidak perlu diedit.

Sebelum mengunggah dokumentasi jaringan, samarkan alamat IP publik, MAC address, kredensial, token, hostname, atau informasi internal yang sensitif.

## Upload ke GitHub

1. Buat repository baru di GitHub, misalnya `faris-portfolio`.
2. Ekstrak ZIP ini di komputer.
3. Buka repository GitHub, pilih **Add file → Upload files**.
4. Upload **isi folder proyek** (index.html, README.md, folder `assets`, `css`, `js`, serta file konfigurasi), bukan hanya file ZIP.
5. Commit perubahan.

## Publikasikan dengan GitHub Pages

1. Buka repository → **Settings → Pages**.
2. Pada bagian build/deployment, pilih **Deploy from a branch**.
3. Pilih branch `main` dan folder `/ (root)`, lalu simpan.
4. Tunggu proses deployment selesai. URL website akan muncul pada halaman Pages.

Pastikan `index.html` berada di root repository, bukan di dalam subfolder tambahan. File `.nojekyll` disertakan agar GitHub Pages menyajikan direktori statis tanpa pemrosesan Jekyll.

## Teknologi

- HTML5
- Tailwind CSS melalui CDN
- CSS khusus (`css/style.css`)
- JavaScript vanilla (`js/main.js`)

Tidak membutuhkan backend, database, build step, `npm install`, atau environment variable.

## Catatan konten

Deskripsi proyek mencerminkan status yang tertulis pada versi portfolio sumber. Khusus deployment virtual server dengan ngrok, konten masih ditandai sebagai rencana/praktik. Perbarui deskripsinya setelah proses deployment benar-benar berhasil dan terdokumentasi.
