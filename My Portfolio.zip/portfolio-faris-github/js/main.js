/**
     * =========================================================================
     * KONFIGURASI MEDIA & FOTO PORTFOLIO (SIAP HOSTING NETLIFY)
     * Letakkan folder "assets/" sejajar dengan file "index.html", lalu isi
     * dengan file foto sesuai daftar path di bawah ini.
     * =========================================================================
     */
    const PORTFOLIO_MEDIA = {
      // 1. Foto Profil Utama pada Hero Section (disarankan rasio portrait 4:5)
      profilePhoto: "assets/foto-faris.jpg",

      // 2. Kompilasi Foto Kegiatan PKL di PT INTENS (disarankan rasio portrait 4:5)
      pklPhotos: [
        {
          src: "assets/pkl-1.jpg",
          alt: "Dokumentasi PKL PT INTENS 1 — Sistem e-Voting",
          caption: "Persiapan & demonstrasi sistem e-Voting"
        },
        {
          src: "assets/pkl-2.jpg",
          alt: "Dokumentasi PKL PT INTENS 2 — Perawatan All-in-One PC",
          caption: "Upgrade RAM, migrasi SSD & perawatan PC"
        },
        {
          src: "assets/pkl-3.jpg",
          alt: "Dokumentasi PKL PT INTENS 3 — Server HPE ProLiant & ESXi",
          caption: "Server HPE ProLiant & virtualisasi VMware ESXi"
        },
        {
          src: "assets/pkl-4.jpg",
          alt: "Dokumentasi PKL PT INTENS 4 — Jaringan & Dokumentasi",
          caption: "Crimping LAN, Wi-Fi AP & dokumentasi tim"
        }
      ],

      // 3. Foto Kegiatan untuk Setiap Modal Proyek & Lab (disarankan rasio landscape)
      projectPhotos: {
        1: "assets/proyek-nmap.jpg",      // Network Discovery & Port Scanning | Nmap
        2: "assets/proyek-windows.jpg",   // Windows Software Troubleshooting & Repair
        3: "assets/proyek-ngrok.jpg",     // Virtual Server Deployment & Public Access via ngrok
        4: "assets/proyek-mikrotik.jpg",  // Network Lab | MikroTik & Cisco Packet Tracer
        5: "assets/proyek-debian.jpg",    // Linux Server Lab | Debian & VMware
        6: "assets/proyek-wireshark.jpg"  // Traffic Analysis | Wireshark & TShark
      }
    };

    // Sinkronisasi Foto Profil Hero dari PORTFOLIO_MEDIA
    const heroProfileImg = document.getElementById("heroProfileImg");
    const heroProfileFallbackPath = document.getElementById("heroProfileFallbackPath");
    if (heroProfileImg) {
      if (heroProfileFallbackPath) {
        heroProfileFallbackPath.textContent = PORTFOLIO_MEDIA.profilePhoto;
      }
      heroProfileImg.src = PORTFOLIO_MEDIA.profilePhoto;
    }

    // =========================================================================
    // KOMPILASI FOTO PKL BERTUMPUK (STACKED PHOTO COMPILATION + BLUR ~40%)
    // =========================================================================
    const pklPhotoStack = document.getElementById("pklPhotoStack");
    const pklCounter = document.getElementById("pklCounter");
    const pklCaption = document.getElementById("pklCaption");
    const pklPrevBtn = document.getElementById("pklPrevBtn");
    const pklNextBtn = document.getElementById("pklNextBtn");

    let activePklIndex = 0;

    function initPklPhotoStack() {
      const photos = PORTFOLIO_MEDIA.pklPhotos || [];
      if (!pklPhotoStack || photos.length === 0) return;

      pklPhotoStack.innerHTML = photos.map((photo, idx) => `
        <div
          data-pkl-index="${idx}"
          class="pkl-stack-card absolute inset-0 rounded-[24px] bg-[#F5F5F7] border border-black/[0.08] overflow-hidden cursor-pointer"
        >
          <img
            src="${photo.src}"
            alt="${photo.alt}"
            class="w-full h-full object-cover object-center pointer-events-none"
            onerror="showMediaFallback(this)"
          />
          <div class="media-fallback hidden absolute inset-0 flex flex-col items-center justify-center p-5 text-center bg-[#F5F5F7]">
            <div class="w-10 h-10 rounded-2xl bg-white border border-black/[0.08] flex items-center justify-center text-[#86868B] mb-2.5">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
                <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />
              </svg>
            </div>
            <p class="text-[12px] font-medium text-[#1D1D1F] mb-1">Foto PKL #${idx + 1}</p>
            <code data-fallback-path class="text-[11px] text-[#86868B] bg-white px-2.5 py-0.5 rounded-full border border-black/[0.06]">
              ${photo.src}
            </code>
          </div>
        </div>
      `).join("");

      // Klik kartu belakang untuk memajukan slide
      pklPhotoStack.querySelectorAll(".pkl-stack-card").forEach(card => {
        card.addEventListener("click", () => {
          const clickedIdx = Number(card.dataset.pklIndex);
          if (clickedIdx !== activePklIndex) {
            activePklIndex = clickedIdx;
            updatePklPhotoStack();
          } else {
            nextPklPhoto();
          }
        });
      });

      updatePklPhotoStack();
    }

    function updatePklPhotoStack() {
      const photos = PORTFOLIO_MEDIA.pklPhotos || [];
      const total = photos.length;
      if (total === 0) return;

      const cards = pklPhotoStack.querySelectorAll(".pkl-stack-card");
      cards.forEach((card, i) => {
        const rel = (i - activePklIndex + total) % total;

        if (rel === 0) {
          // Foto aktif di posisi paling depan: tajam & jelas
          card.style.zIndex = "30";
          card.style.opacity = "1";
          card.style.filter = "blur(0px)";
          card.style.transform = "translate3d(0px, 0px, 0px) scale(1) rotate(0deg)";
          card.style.boxShadow = "0 18px 40px -14px rgba(0, 0, 0, 0.14)";
        } else if (rel === 1) {
          // Foto kedua di belakang kanan dengan efek blur ~40%
          card.style.zIndex = "20";
          card.style.opacity = "0.78";
          card.style.filter = "blur(4px)";
          card.style.transform = "translate3d(16px, 10px, 0px) scale(0.93) rotate(3deg)";
          card.style.boxShadow = "0 10px 24px -10px rgba(0, 0, 0, 0.08)";
        } else if (rel === 2) {
          // Foto ketiga di belakang kiri dengan efek blur ~40%
          card.style.zIndex = "10";
          card.style.opacity = "0.64";
          card.style.filter = "blur(4.8px)";
          card.style.transform = "translate3d(-15px, 17px, 0px) scale(0.87) rotate(-3deg)";
          card.style.boxShadow = "0 8px 20px -10px rgba(0, 0, 0, 0.06)";
        } else {
          // Foto sisa tertumpuk rapi di lapisan terdalam
          card.style.zIndex = "5";
          card.style.opacity = "0.45";
          card.style.filter = "blur(5.2px)";
          card.style.transform = "translate3d(0px, 22px, 0px) scale(0.82) rotate(1.5deg)";
          card.style.boxShadow = "none";
        }
      });

      const currentFormatted = String(activePklIndex + 1).padStart(2, "0");
      const totalFormatted = String(total).padStart(2, "0");
      if (pklCounter) pklCounter.textContent = `${currentFormatted} / ${totalFormatted}`;
      if (pklCaption) pklCaption.textContent = photos[activePklIndex].caption;
    }

    function nextPklPhoto() {
      const total = PORTFOLIO_MEDIA.pklPhotos.length;
      activePklIndex = (activePklIndex + 1) % total;
      updatePklPhotoStack();
    }

    function prevPklPhoto() {
      const total = PORTFOLIO_MEDIA.pklPhotos.length;
      activePklIndex = (activePklIndex - 1 + total) % total;
      updatePklPhotoStack();
    }

    if (pklNextBtn) pklNextBtn.addEventListener("click", nextPklPhoto);
    if (pklPrevBtn) pklPrevBtn.addEventListener("click", prevPklPhoto);

    // Dukungan swipe sentuh pada mobile untuk kompilasi foto PKL
    let pklTouchStartX = 0;
    if (pklPhotoStack) {
      pklPhotoStack.addEventListener("touchstart", (e) => {
        pklTouchStartX = e.changedTouches[0].screenX;
      }, { passive: true });

      pklPhotoStack.addEventListener("touchend", (e) => {
        const touchEndX = e.changedTouches[0].screenX;
        const deltaX = touchEndX - pklTouchStartX;
        if (Math.abs(deltaX) > 36) {
          if (deltaX < 0) nextPklPhoto();
          else prevPklPhoto();
        }
      }, { passive: true });
    }

    initPklPhotoStack();

    // Data lengkap 6 Proyek & Praktik Teknis sesuai CV
    const projectsData = [
      {
        id: 1,
        title: "Network Discovery & Port Scanning | Nmap",
        categoryLabel: "Jaringan",
        filters: ["jaringan", "sistem"],
        image: PORTFOLIO_MEDIA.projectPhotos[1],
        summary: "Praktik discovery host dan pemindaian port pada jaringan yang diizinkan untuk mengenali host aktif, port terbuka, serta informasi service dasar.",
        highlights: [
          "Identifikasi host aktif (host discovery) pada segmen jaringan lokal yang diizinkan.",
          "Pemindaian status port terbuka untuk memetakan layanan jaringan yang berjalan.",
          "Pembacaan informasi service dasar sebagai bagian dari audit dan pemecahan masalah konektivitas."
        ],
        tools: ["Nmap", "TCP/IP", "IPv4", "Network Troubleshooting"]
      },
      {
        id: 2,
        title: "Windows Software Troubleshooting & Repair",
        categoryLabel: "Sistem & Troubleshooting",
        filters: ["sistem"],
        image: PORTFOLIO_MEDIA.projectPhotos[2],
        summary: "Praktik diagnosis dan penanganan masalah software Windows, termasuk pemeriksaan sistem, troubleshooting error aplikasi, dan pemulihan fungsi perangkat.",
        highlights: [
          "Pemeriksaan kesehatan sistem operasi Windows dan identifikasi akar penyebab gangguan.",
          "Penanganan error aplikasi serta penyesuaian konfigurasi sistem agar kembali stabil.",
          "Pemulihan fungsi perangkat kerja secara sistematis."
        ],
        tools: ["Windows", "System Diagnostics", "OS Recovery"]
      },
      {
        id: 3,
        title: "Virtual Server Deployment & Public Access via ngrok",
        categoryLabel: "Server & Virtualisasi",
        filters: ["server", "jaringan"],
        image: PORTFOLIO_MEDIA.projectPhotos[3],
        summary: "Rencana/praktik deployment web server Linux pada lingkungan virtualisasi dan publikasi layanan web lokal melalui secure tunnel ngrok, tanpa konfigurasi port forwarding router.",
        highlights: [
          "Penyiapan lingkungan virtualisasi untuk menjalankan web server berbasis Linux.",
          "Pengujian layanan web lokal (Apache) pada mesin virtual.",
          "Publikasi akses layanan lokal menggunakan secure tunnel ngrok tanpa mengubah pengaturan port forwarding router."
        ],
        tools: ["Linux", "Apache (rencana/praktik)", "VMware", "ngrok (praktik/rencana)"]
      },
      {
        id: 4,
        title: "Network Lab | MikroTik & Cisco Packet Tracer",
        categoryLabel: "Jaringan",
        filters: ["jaringan"],
        image: PORTFOLIO_MEDIA.projectPhotos[4],
        summary: "Konfigurasi MikroTik untuk routing, WLAN, dan pembatasan akses klien; praktik static routing, VLAN, serta inter-VLAN routing.",
        highlights: [
          "Konfigurasi dasar router MikroTik untuk manajemen routing, jaringan nirkabel (WLAN), serta pembatasan akses klien.",
          "Simulasi segmentasi jaringan menggunakan VLAN dan inter-VLAN routing di Cisco Packet Tracer.",
          "Implementasi static routing antar jaringan untuk memastikan komunikasi lintas segmen."
        ],
        tools: ["MikroTik", "WinBox", "Cisco Packet Tracer", "VLAN", "Static Routing"]
      },
      {
        id: 5,
        title: "Linux Server Lab | Debian & VMware",
        categoryLabel: "Server & Virtualisasi",
        filters: ["server"],
        image: PORTFOLIO_MEDIA.projectPhotos[5],
        summary: "Instalasi dan konfigurasi DHCP Server pada Debian Linux di VMware; mempelajari dasar Windows Server dan administrasi jaringan.",
        highlights: [
          "Instalasi sistem operasi Debian Linux pada lingkungan virtual VMware.",
          "Konfigurasi layanan DHCP Server untuk distribusi alamat IP otomatis pada klien jaringan.",
          "Pengenalan dasar Windows Server dan administrasi layanan jaringan."
        ],
        tools: ["Debian Linux", "DHCP Server", "VMware", "Windows Server (dasar)"]
      },
      {
        id: 6,
        title: "Traffic Analysis | Wireshark & TShark",
        categoryLabel: "Jaringan",
        filters: ["jaringan", "sistem"],
        image: PORTFOLIO_MEDIA.projectPhotos[6],
        summary: "Praktik dasar menangkap dan memfilter paket jaringan; mempelajari konsep routing dinamis EIGRP dan RIP melalui simulasi.",
        highlights: [
          "Penangkapan (packet capture) dan penyaringan lalu lintas data jaringan menggunakan Wireshark dan TShark.",
          "Analisis alur komunikasi protokol dasar untuk mendiagnosis perilaku jaringan.",
          "Simulasi konsep protokol routing dinamis EIGRP dan RIP."
        ],
        tools: ["Wireshark", "TShark", "TCP/IP", "EIGRP & RIP (Simulasi)"]
      }
    ];

    const projectsGrid = document.getElementById("projectsGrid");
    const filterButtons = document.querySelectorAll("[data-filter]");

    // Render kartu proyek ke dalam grid
    function renderProjects(filterCategory = "semua") {
      if (!projectsGrid) return;

      const filtered = filterCategory === "semua"
        ? projectsData
        : projectsData.filter(item => item.filters.includes(filterCategory));

      projectsGrid.innerHTML = filtered.map(project => `
        <article
          data-project-id="${project.id}"
          tabindex="0"
          role="button"
          aria-label="Lihat detail proyek ${project.title}"
          class="bento-card p-7 sm:p-8 flex flex-col justify-between cursor-pointer group focus:outline-none focus:ring-2 focus:ring-[#1D1D1F]/20"
        >
          <div>
            <div class="flex items-center justify-between gap-3 mb-4">
              <span class="px-3 py-1 rounded-full bg-white border border-black/[0.08] text-[12px] font-medium text-[#424245]">
                ${project.categoryLabel}
              </span>
              <span class="w-8 h-8 rounded-full bg-white border border-black/[0.08] flex items-center justify-center text-[#86868B] group-hover:text-[#1D1D1F] group-hover:translate-x-0.5 transition-all">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
              </span>
            </div>

            <h3 class="text-[20px] sm:text-[22px] font-bold tracking-apple-tight leading-[1.24] text-[#1D1D1F] mb-3">
              ${project.title}
            </h3>

            <p class="text-[14px] sm:text-[15px] leading-[1.6] text-[#424245] mb-6">
              ${project.summary}
            </p>
          </div>

          <div class="pt-4 border-t border-black/[0.06] flex items-center justify-between gap-2">
            <div class="flex flex-wrap gap-1.5">
              ${project.tools.slice(0, 3).map(tool => `
                <span class="px-2.5 py-0.5 rounded-full bg-white/80 border border-black/[0.06] text-[11px] text-[#424245]">
                  ${tool}
                </span>
              `).join("")}
            </div>
            <span class="text-[12px] font-medium text-[#1D1D1F] shrink-0 group-hover:underline">
              Detail
            </span>
          </div>
        </article>
      `).join("");

      // Tambahkan event listener klik & keyboard Enter/Space pada tiap kartu
      projectsGrid.querySelectorAll("[data-project-id]").forEach(card => {
        const id = Number(card.dataset.projectId);
        card.addEventListener("click", () => openProjectModal(id));
        card.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            openProjectModal(id);
          }
        });
      });
    }

    // Event listener untuk segmented control filter
    filterButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        filterButtons.forEach(b => {
          b.classList.remove("active");
          b.setAttribute("aria-selected", "false");
        });
        btn.classList.add("active");
        btn.setAttribute("aria-selected", "true");
        renderProjects(btn.dataset.filter);
      });
    });

    // Inisialisasi render proyek awal
    renderProjects("semua");

    // Logika Modal Detail Proyek
    const projectModal = document.getElementById("projectModal");
    const closeModalBtn = document.getElementById("closeModalBtn");

    function openProjectModal(projectId) {
      const project = projectsData.find(p => p.id === projectId);
      if (!project || !projectModal) return;

      // Muat foto kegiatan proyek di bagian atas modal dengan reset fallback
      const modalImg = document.getElementById("modalProjectImg");
      const modalFallbackPath = document.getElementById("modalFallbackPath");
      if (modalImg) {
        const modalFallbackBox = modalImg.parentElement.querySelector(".media-fallback");
        if (modalFallbackBox) modalFallbackBox.classList.add("hidden");
        modalImg.classList.remove("hidden");
        if (modalFallbackPath) modalFallbackPath.textContent = project.image;
        modalImg.alt = `Dokumentasi ${project.title}`;
        modalImg.src = project.image;
      }

      document.getElementById("modalCategory").textContent = project.categoryLabel;
      document.getElementById("modalTitle").textContent = project.title;
      document.getElementById("modalDescription").textContent = project.summary;

      const highlightsEl = document.getElementById("modalHighlights");
      highlightsEl.innerHTML = project.highlights.map(item => `
        <li class="flex items-start gap-2.5">
          <span class="w-1.5 h-1.5 rounded-full bg-[#1D1D1F] mt-2 shrink-0"></span>
          <span class="leading-[1.55]">${item}</span>
        </li>
      `).join("");

      const toolsEl = document.getElementById("modalTools");
      toolsEl.innerHTML = project.tools.map(tool => `
        <span class="px-3.5 py-1.5 rounded-full bg-[#F5F5F7] border border-black/[0.08] text-[13px] font-medium text-[#1D1D1F]">
          ${tool}
        </span>
      `).join("");

      projectModal.classList.add("open");
      document.body.style.overflow = "hidden";
    }

    function closeProjectModal() {
      if (!projectModal) return;
      projectModal.classList.remove("open");
      document.body.style.overflow = "";
    }

    if (closeModalBtn) {
      closeModalBtn.addEventListener("click", closeProjectModal);
    }

    if (projectModal) {
      projectModal.addEventListener("click", (e) => {
        if (e.target === projectModal) {
          closeProjectModal();
        }
      });
    }

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && projectModal && projectModal.classList.contains("open")) {
        closeProjectModal();
      }
    });

    // Logika Menu Mobile
    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenuDrawer = document.getElementById("mobileMenuDrawer");
    const menuIconOpen = document.getElementById("menuIconOpen");
    const menuIconClose = document.getElementById("menuIconClose");
    const mobileNavLinks = document.querySelectorAll(".mobile-nav-link");

    function toggleMobileMenu(forceClose = false) {
      if (!mobileMenuDrawer || !mobileMenuBtn) return;
      const isCurrentlyOpen = !mobileMenuDrawer.classList.contains("hidden");
      const shouldOpen = forceClose ? false : !isCurrentlyOpen;

      if (shouldOpen) {
        mobileMenuDrawer.classList.remove("hidden");
        menuIconOpen.classList.add("hidden");
        menuIconClose.classList.remove("hidden");
        mobileMenuBtn.setAttribute("aria-expanded", "true");
      } else {
        mobileMenuDrawer.classList.add("hidden");
        menuIconOpen.classList.remove("hidden");
        menuIconClose.classList.add("hidden");
        mobileMenuBtn.setAttribute("aria-expanded", "false");
      }
    }

    if (mobileMenuBtn) {
      mobileMenuBtn.addEventListener("click", () => toggleMobileMenu(false));
    }

    mobileNavLinks.forEach(link => {
      link.addEventListener("click", () => toggleMobileMenu(true));
    });

    // Logika Salin Teks ke Clipboard + Notifikasi Toast Halus
    let toastTimeout = null;

    function showToast(message) {
      const toast = document.getElementById("toastNotification");
      const toastMsg = document.getElementById("toastMessage");
      if (!toast || !toastMsg) return;

      toastMsg.textContent = message;
      toast.classList.remove("opacity-0", "translate-y-3");
      toast.classList.add("opacity-100", "translate-y-0");

      if (toastTimeout) clearTimeout(toastTimeout);
      toastTimeout = setTimeout(() => {
        toast.classList.remove("opacity-100", "translate-y-0");
        toast.classList.add("opacity-0", "translate-y-3");
      }, 2600);
    }

    function copyToClipboard(text, successMessage = "Berhasil disalin") {
      try {
        const tempInput = document.createElement("textarea");
        tempInput.value = text;
        tempInput.setAttribute("readonly", "");
        tempInput.style.position = "absolute";
        tempInput.style.left = "-9999px";
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);
        showToast(successMessage);
      } catch (err) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(() => showToast(successMessage));
        }
      }
    }

    // Animasi Scroll-Reveal Halus dengan IntersectionObserver
    const revealItems = document.querySelectorAll(".reveal-item");
    if ("IntersectionObserver" in window) {
      const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      }, {
        threshold: 0.08,
        rootMargin: "0px 0px -24px 0px"
      });

      revealItems.forEach(item => revealObserver.observe(item));
    } else {
      revealItems.forEach(item => item.classList.add("is-visible"));
    }
